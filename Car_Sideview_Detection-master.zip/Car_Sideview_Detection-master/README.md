# Car_Sideview_Detection
Resources for sideview car detection, An xml file with the description of a cascade classifier for sideview car detection for OpenCV. Also a database of 948 sideview cars and 3122 negative template images in pgm format. The images are 40x100 pixel resolution.

You can also find a python script to read camera frames and detect cars. Just make sure that the xml is in the same folder as the python file.
